A Pen created at CodePen.io. You can find this one at http://codepen.io/VictoryDesign/pen/PqQevB.

 Envato Remix Challenge - Responsive profile card with beautiful animations.